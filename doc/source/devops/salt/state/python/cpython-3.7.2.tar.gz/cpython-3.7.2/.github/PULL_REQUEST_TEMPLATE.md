!!! If this is a backport PR (PR made against branches other than `master`),
please ensure that the PR title is in the following format:

```
[X.Y] <title from the original PR> (GH-NNNN)
```

Where: [X.Y] is the branch name, e.g. [3.7].

GH-NNNN refers to the PR number from `master`.

PLEASE: Remove this headline!!!
